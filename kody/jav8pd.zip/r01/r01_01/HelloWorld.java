package r01.r01_01;

// Nasz pierwszy program w j�zyku Java 

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Witaj, �wiecie!");
    }
}
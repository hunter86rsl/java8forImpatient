package r03.r03_09;

public interface IntSequence {
    boolean hasNext();
    int next();
}
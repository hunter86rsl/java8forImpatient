package r11.r11_02;

public @interface Reference {
    long id();
}
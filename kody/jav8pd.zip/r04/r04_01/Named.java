package r04.r04_01;

public interface Named {
    default String getName() { return ""; }
}
package r04.r04_01;

public class Worker {
    public void work() { 
        for (int i = 0; i < 100; i++) System.out.println("Pracuje"); 
    }
}